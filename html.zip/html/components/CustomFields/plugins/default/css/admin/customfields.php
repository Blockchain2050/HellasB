.customfields-form-admin fieldset.titleform {
    border: 1px groove #ddd !important;
    padding: 0 1.4em 1.4em 1.4em !important;
    margin: 0 0 1.5em 0 !important;
    -webkit-box-shadow:  0px 0px 0px 0px #000;
            box-shadow:  0px 0px 0px 0px #000;
}
.customfields-form-admin legend.titleform {
        font-size: 1.2em !important;
        font-weight: bold !important;
        text-align: left !important;
        width:auto;
        padding:0 10px;
        border-bottom:none;
}
.customfield-list tr {
	cursor:move;
}
.customfield-list a {
	cusrsor:pointer;
}
.customfields-opacity {
	opacity:0.7;
}