<div class="ossn-page-contents">
			<?php
			
					echo ossn_view_form('feedback/add', array(
							'action' => ossn_site_url() . 'action/feedback/add',
					));
			?>
</div>


