<?php
/**
 * Open Source Social Network
 *
 * @packageOpen Source Social Network
 * @author    Open Social Website Core Team <info@informatikon.com>
 * @copyright 2014 iNFORMATIKON TECHNOLOGIES
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      http://www.opensource-socialnetwork.org/licence
 */
?>
<div class="container">
	<div class="row">
    	<div class="col-md-11">
      	  	<div class="alert alert-danger">
					<?php echo ossn_print('banuser:notice'); ?>
			</div>
        </div>
    </div>
</div>