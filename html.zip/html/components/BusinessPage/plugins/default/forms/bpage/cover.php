<input type="file" name="coverphoto" class="coverfile" onchange="Ossn.Clk('#upload-cover-page .upload');" />
<input type="hidden" name="guid" value="<?php echo $params['page']->guid;?>" />
<input type="submit" class="upload">