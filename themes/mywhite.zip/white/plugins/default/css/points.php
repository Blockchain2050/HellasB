.ossn-profile-points {
    font-size: 20px !important;
    margin-top: 0px !important;
  	color: #FFD700 !important;
}
