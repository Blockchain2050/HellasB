//<script>
Ossn.RegisterStartupFunction(function() {
	$(document).ready(function() {
		$('.profile-photo').unbind('mouseenter mouseleave'); 
		$('.upload-photo').show();
	});
});