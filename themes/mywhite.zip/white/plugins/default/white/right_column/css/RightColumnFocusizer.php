.sidebar-footer {
	margin-top: 0px;
	padding-top: 0px;
	text-align: center;
}

.sidebar-footer .ossn-footer-menu a::after {
	content: "|";
	margin-left: 10px;
	margin-right: 10px;
}

.sidebar-footer .ossn-footer-menu a:nth-last-child(2)::after {
	content: "|";
}

.sidebar-footer .ossn-footer-menu a:last-child::after {
	content: "";
}
