<input type="text" name="q" placeholder="&#xf002; <?php echo ossn_print('ossn:search');?>" />
