<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="footer-contents">
					<div class="ossn-footer-menu">
						<?php echo ossn_view_menu('footer'); ?>
					</div>
					<?php echo ossn_fetch_extend_views('ossn/page/footer/contents'); ?>
				</div>
			</div>
		</div>
	</div>
</footer>