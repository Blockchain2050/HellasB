<?php
	if(!ossn_isLoggedin()){
		return;
	}
?>
