<?php
echo ossn_view_form('awesome/images', array(
    'action' => ossn_site_url() . 'action/awesome/settings/images',
	'class' => 'awesome-form-admin',	
));

