<?php
	if(!ossn_isLoggedin()){
		return;
	}
?>
        <div class="sidebar">
            <div class="sidebar-contents">

           		
            </div>
        </div>