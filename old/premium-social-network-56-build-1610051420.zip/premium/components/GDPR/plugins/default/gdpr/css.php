.menu-topbar-dropdown-deleteaccount {
		 color: #ff1919 !important;
}
.gdpr a {
	font-weight:bold;
}