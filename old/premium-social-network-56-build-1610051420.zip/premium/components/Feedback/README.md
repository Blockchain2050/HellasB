Feedback
========

Allow your website users to provide feedback to you.  The feedback button appears on the bottom right corner.  The button disappear automatically if :

1. User provide the feedback or,
2. User didn't provide feedback and visited the site more than 3 times.