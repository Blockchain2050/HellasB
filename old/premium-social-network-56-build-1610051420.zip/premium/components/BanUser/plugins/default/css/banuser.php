.profile-menu-extra-banuser {
    color: #B91A1A !important;
}