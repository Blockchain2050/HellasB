@media (max-width: 480px) {
	.ossn-users-list-item img {
    	display: block !important;
    	width: 100%;
   	 	height: 100%;
	}
}
.menu-section-item-emembers-female:before {
    font-family: FontAwesome;
    content: "\f182" !important;
}
.menu-section-item-emembers-male:before {
    font-family: FontAwesome;
    content: "\f183" !important;
}
.menu-section-emembers i:before {
    content: "\f0c0" !important;
}