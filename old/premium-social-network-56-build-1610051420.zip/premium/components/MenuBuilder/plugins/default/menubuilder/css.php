.menubuilder-item-topbar-dropdown i {
	    font-size: 15px !important;
}