.categories h3 {
    margin-top: 0px;
    font-size: 21px;
    margin-bottom: 5px;
}
.categories p {
	margin-bottom:5px;
}
.categories .ossn-users-list-item {
	margin-left: -5px;
    margin-right: -5px;
}