<a href="<?php echo ossn_site_url('action/social/login/facebook', true);?>" class="btn btn-block btn-social btn-facebook btn-sm">
  <span class="fa fa-facebook"></span>
  <?php echo ossn_print('social:login:with:facebook');?>
</a>
<a href="<?php echo ossn_site_url('action/social/login/twitter', true);?>" class="btn btn-block btn-social btn-twitter btn-sm">
  <span class="fa fa-twitter"></span>
  <?php echo ossn_print('social:login:with:twitter');?>
</a>
