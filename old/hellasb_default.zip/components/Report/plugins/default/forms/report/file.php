<div>
	<label>Reason</label>
	<textarea name="reason"></textarea>
</div>
<input type="hidden" name="guid" value="<?Php echo input('data-guid');?>" />
<input type="hidden" name="type" value="<?php echo input('data-type');?>" />
<input type="submit" class="hidden" id="ossn-file-report" />
