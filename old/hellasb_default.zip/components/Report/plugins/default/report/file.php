<?php
/**
 * Open Source Social Network
 *
 * @package Open Source Social Network
 * @author    Open Social Website Core Team <info@softlab24.com>
 * @copyright 2014-2017 SOFTLAB24 LIMITED
 * @license   SOFTLAB24 COMMERICAL ITEMS LICENSE v1  https://www.softlab24.com/license/
 * @link      https://www.softlab24.com/
 */
 echo ossn_view_form('report/file', array(
		'action' => ossn_site_url() . 'action/report/file',
		'id' => 'ossn-report-file',
 ));