.report-item {
    padding: 10px;
    border: 1px solid #eee;
    margin-bottom: 10px;
    background: #f3f3f3;
}
.report-item p {
    border-bottom: 1px solid #ccc;
    padding: 5px;	
}
.report-item-read {
	background:#fff;	
}
.report-item p span {
    margin-left: 5px;	
}
.report-item .btn {
	margin-right:5px;
}