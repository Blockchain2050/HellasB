.groupinvite .token-input-input-token {
	width:100%;
    margin-top:10px;
}
.groupinvite .token-input-list {
	border-left:0px;
    border-right:0px;
    border-top:0px;
}
.fa-groupinvite {
	margin-right:0px;
}