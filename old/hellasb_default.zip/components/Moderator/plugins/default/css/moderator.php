.profile-menu-extra-delete_user {
	color: #B91A1A !important;
}