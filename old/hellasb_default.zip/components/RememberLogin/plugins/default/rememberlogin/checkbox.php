<input id="kmli" type="checkbox" name="rememberlogin"> <?php echo ossn_print('com:rememberlogin:keep:login'); ?><br>
<!-- <p>Your browser fingerprint: <strong id="fp"></strong></p> -->
