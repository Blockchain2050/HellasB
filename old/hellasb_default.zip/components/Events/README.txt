Events Component
=================

1.) Allow you to create events.
2.) Allow users to Mark even as going, interested or nointerested.
3.) Allow users comments/like the event.
4.) Allow users to view who is going to event, who is interested or nointerested.
5.) Event owner gets notification when someone likes, comments or mark event as going to.
6.) Search events.
7.) Allow event owner to enable/disable comments.
8.) A wall post notfication if someone creates event.