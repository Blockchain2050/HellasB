.ossn-site-pages-title {
    background: var(--main-titles-bg-color);
    border: 1px solid var(--main-border-color-bit);
    padding: 10px;
    font-weight: bold;
}
.ossn-site-pages-body {
    padding: 10px;
}
