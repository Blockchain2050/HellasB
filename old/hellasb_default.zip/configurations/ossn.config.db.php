<?php
/**
 * Open Source Social Network
 *
 * @package   (softlab24.com).ossn
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */


// replace localhost:3306 with your database host name;
$Ossn->host = 'localhost:3306';

// replace 3306 with your database host name;
$Ossn->port = '3306';

// replace user7062815015_hellasbu with your database username;
$Ossn->user = 'user7062815015_hellasbu';

// replace o(qnbC-O*_C4 with your database password;
$Ossn->password = 'o(qnbC-O*_C4';

// replace user7062815015_hellasb with your database name;
$Ossn->database = 'user7062815015_hellasb';