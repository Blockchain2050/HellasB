.sentiment-positive {
	color:#3BE232;
}
.sentiment-negative {
	    color: #F53737;
}
.sentiment-neutral {
	color: #F5D637;
}